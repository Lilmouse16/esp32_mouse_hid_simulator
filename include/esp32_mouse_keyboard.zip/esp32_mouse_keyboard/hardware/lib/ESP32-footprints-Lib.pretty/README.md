# Acknowledgements

KiCAD footprint by adamjvr:

https://github.com/adamjvr/ESP32-kiCAD-Footprints

3D wrl model by Stuckinloop:

https://github.com/StuckInLoop/esp-wroom-32-3d-step-and-iges-models


